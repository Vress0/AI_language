print('a\ta^2\ta^3\n')
for i in range(1,5):
    print(str(i)+'\t'+str(i**2)+'\t'+str(i**3)+'\n')