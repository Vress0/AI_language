radius = eval(input('Please input the radius:'))
area = radius * radius * 3.14159
print('The area for the circle of radius', radius, ' is', area)