song = """When an eel grabs your arm,
And it causes great harm,
That's - a moray!"""

print(song.replace(' m', ' M'))