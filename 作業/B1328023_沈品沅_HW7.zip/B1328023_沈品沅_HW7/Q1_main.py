import Q1_zoo as menagerie
from Q1_zoo import hours


menagerie.hours()

hours()